Homework 2 Readme file

Before running:
  training file must be in the root directory

To run:
  `python3 homework2.py <trianing_file_name> <{0|1}>`

Once complete, the output will be appended to a file named "out.txt"
The test sentences are hard-coded, but could easily be replaced by others.
